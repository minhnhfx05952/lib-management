﻿namespace GUI.UserControls
{
    partial class ucThayDoiQuiDinh
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucThayDoiQuiDinh));
            this.infoPanel = new Siticone.Desktop.UI.WinForms.SiticonePanel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.siticonePanel10 = new Siticone.Desktop.UI.WinForms.SiticonePanel();
            this.siticonePanel3 = new Siticone.Desktop.UI.WinForms.SiticonePanel();
            this.numTuoiMax = new Siticone.Desktop.UI.WinForms.SiticoneNumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.siticonePanel4 = new Siticone.Desktop.UI.WinForms.SiticonePanel();
            this.numTuoiMin = new Siticone.Desktop.UI.WinForms.SiticoneNumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.siticonePanel5 = new Siticone.Desktop.UI.WinForms.SiticonePanel();
            this.label9 = new System.Windows.Forms.Label();
            this.numThoiHan = new Siticone.Desktop.UI.WinForms.SiticoneNumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.siticonePanel1 = new Siticone.Desktop.UI.WinForms.SiticonePanel();
            this.siticoneSeparator1 = new Siticone.Desktop.UI.WinForms.SiticoneSeparator();
            this.label1 = new System.Windows.Forms.Label();
            this.siticonePanel11 = new Siticone.Desktop.UI.WinForms.SiticonePanel();
            this.butSave = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.siticonePanel6 = new Siticone.Desktop.UI.WinForms.SiticonePanel();
            this.checkQDThu = new Siticone.Desktop.UI.WinForms.SiticoneImageCheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.siticonePanel2 = new Siticone.Desktop.UI.WinForms.SiticonePanel();
            this.label14 = new System.Windows.Forms.Label();
            this.numKcNam = new Siticone.Desktop.UI.WinForms.SiticoneNumericUpDown();
            this.label15 = new System.Windows.Forms.Label();
            this.siticonePanel9 = new Siticone.Desktop.UI.WinForms.SiticonePanel();
            this.label17 = new System.Windows.Forms.Label();
            this.numSoSach = new Siticone.Desktop.UI.WinForms.SiticoneNumericUpDown();
            this.label22 = new System.Windows.Forms.Label();
            this.siticonePanel7 = new Siticone.Desktop.UI.WinForms.SiticonePanel();
            this.label18 = new System.Windows.Forms.Label();
            this.txtDonGia = new Siticone.Desktop.UI.WinForms.SiticoneTextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.siticonePanel8 = new Siticone.Desktop.UI.WinForms.SiticonePanel();
            this.label20 = new System.Windows.Forms.Label();
            this.numNgayMuon = new Siticone.Desktop.UI.WinForms.SiticoneNumericUpDown();
            this.label21 = new System.Windows.Forms.Label();
            this.siticoneSeparator2 = new Siticone.Desktop.UI.WinForms.SiticoneSeparator();
            this.label16 = new System.Windows.Forms.Label();
            this.infoPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.siticonePanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numTuoiMax)).BeginInit();
            this.siticonePanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numTuoiMin)).BeginInit();
            this.siticonePanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numThoiHan)).BeginInit();
            this.siticonePanel11.SuspendLayout();
            this.siticonePanel6.SuspendLayout();
            this.siticonePanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numKcNam)).BeginInit();
            this.siticonePanel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSoSach)).BeginInit();
            this.siticonePanel7.SuspendLayout();
            this.siticonePanel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numNgayMuon)).BeginInit();
            this.SuspendLayout();
            // 
            // infoPanel
            // 
            this.infoPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(241)))), ((int)(((byte)(255)))));
            this.infoPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(177)))), ((int)(((byte)(178)))), ((int)(((byte)(255)))));
            this.infoPanel.BorderRadius = 5;
            this.infoPanel.BorderThickness = 2;
            this.infoPanel.Controls.Add(this.splitContainer1);
            this.infoPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.infoPanel.Location = new System.Drawing.Point(0, 0);
            this.infoPanel.Margin = new System.Windows.Forms.Padding(10, 10, 12, 10);
            this.infoPanel.Name = "infoPanel";
            this.infoPanel.Padding = new System.Windows.Forms.Padding(8, 8, 8, 8);
            this.infoPanel.Size = new System.Drawing.Size(742, 646);
            this.infoPanel.TabIndex = 1;
            // 
            // splitContainer1
            // 
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.IsSplitterFixed = true;
            this.splitContainer1.Location = new System.Drawing.Point(8, 8);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(19, 20, 19, 20);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.siticonePanel10);
            this.splitContainer1.Panel1.Controls.Add(this.siticonePanel3);
            this.splitContainer1.Panel1.Controls.Add(this.siticonePanel4);
            this.splitContainer1.Panel1.Controls.Add(this.siticonePanel5);
            this.splitContainer1.Panel1.Controls.Add(this.siticonePanel1);
            this.splitContainer1.Panel1.Controls.Add(this.siticoneSeparator1);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            this.splitContainer1.Panel1.Margin = new System.Windows.Forms.Padding(15, 16, 15, 16);
            this.splitContainer1.Panel1.Padding = new System.Windows.Forms.Padding(15, 16, 15, 16);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.siticonePanel11);
            this.splitContainer1.Panel2.Controls.Add(this.siticonePanel6);
            this.splitContainer1.Panel2.Controls.Add(this.siticonePanel2);
            this.splitContainer1.Panel2.Controls.Add(this.siticonePanel9);
            this.splitContainer1.Panel2.Controls.Add(this.siticonePanel7);
            this.splitContainer1.Panel2.Controls.Add(this.siticonePanel8);
            this.splitContainer1.Panel2.Controls.Add(this.siticoneSeparator2);
            this.splitContainer1.Panel2.Controls.Add(this.label16);
            this.splitContainer1.Panel2.Margin = new System.Windows.Forms.Padding(15, 16, 15, 16);
            this.splitContainer1.Panel2.Padding = new System.Windows.Forms.Padding(15, 16, 15, 16);
            this.splitContainer1.Size = new System.Drawing.Size(726, 630);
            this.splitContainer1.SplitterDistance = 220;
            this.splitContainer1.SplitterWidth = 3;
            this.splitContainer1.TabIndex = 15;
            // 
            // siticonePanel10
            // 
            this.siticonePanel10.CustomBorderColor = System.Drawing.Color.MediumSlateBlue;
            this.siticonePanel10.Dock = System.Windows.Forms.DockStyle.Top;
            this.siticonePanel10.Location = new System.Drawing.Point(15, 158);
            this.siticonePanel10.Margin = new System.Windows.Forms.Padding(3, 1, 3, 3);
            this.siticonePanel10.Name = "siticonePanel10";
            this.siticonePanel10.Padding = new System.Windows.Forms.Padding(0, 10, 0, 4);
            this.siticonePanel10.Size = new System.Drawing.Size(694, 39);
            this.siticonePanel10.TabIndex = 76;
            // 
            // siticonePanel3
            // 
            this.siticonePanel3.Controls.Add(this.numTuoiMax);
            this.siticonePanel3.Controls.Add(this.label3);
            this.siticonePanel3.CustomBorderColor = System.Drawing.Color.MediumSlateBlue;
            this.siticonePanel3.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 1);
            this.siticonePanel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.siticonePanel3.Location = new System.Drawing.Point(15, 129);
            this.siticonePanel3.Margin = new System.Windows.Forms.Padding(3, 1, 3, 3);
            this.siticonePanel3.Name = "siticonePanel3";
            this.siticonePanel3.Padding = new System.Windows.Forms.Padding(0, 10, 0, 4);
            this.siticonePanel3.Size = new System.Drawing.Size(694, 29);
            this.siticonePanel3.TabIndex = 2;
            // 
            // numTuoiMax
            // 
            this.numTuoiMax.BackColor = System.Drawing.Color.Transparent;
            this.numTuoiMax.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.numTuoiMax.Dock = System.Windows.Forms.DockStyle.Left;
            this.numTuoiMax.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.numTuoiMax.Location = new System.Drawing.Point(208, 10);
            this.numTuoiMax.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.numTuoiMax.Minimum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.numTuoiMax.Name = "numTuoiMax";
            this.numTuoiMax.Size = new System.Drawing.Size(52, 15);
            this.numTuoiMax.TabIndex = 74;
            this.numTuoiMax.UpDownButtonFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(177)))), ((int)(((byte)(178)))), ((int)(((byte)(255)))));
            this.numTuoiMax.Value = new decimal(new int[] {
            55,
            0,
            0,
            0});
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Left;
            this.label3.Font = new System.Drawing.Font("Segoe UI Variable Text", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.label3.Location = new System.Drawing.Point(0, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(208, 26);
            this.label3.TabIndex = 0;
            this.label3.Text = "Tuổi tối đa của độc giả:";
            // 
            // siticonePanel4
            // 
            this.siticonePanel4.Controls.Add(this.numTuoiMin);
            this.siticonePanel4.Controls.Add(this.label4);
            this.siticonePanel4.CustomBorderColor = System.Drawing.Color.MediumSlateBlue;
            this.siticonePanel4.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 1);
            this.siticonePanel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.siticonePanel4.Location = new System.Drawing.Point(15, 100);
            this.siticonePanel4.Margin = new System.Windows.Forms.Padding(3, 1, 3, 3);
            this.siticonePanel4.Name = "siticonePanel4";
            this.siticonePanel4.Padding = new System.Windows.Forms.Padding(0, 10, 0, 4);
            this.siticonePanel4.Size = new System.Drawing.Size(694, 29);
            this.siticonePanel4.TabIndex = 3;
            // 
            // numTuoiMin
            // 
            this.numTuoiMin.BackColor = System.Drawing.Color.Transparent;
            this.numTuoiMin.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.numTuoiMin.Dock = System.Windows.Forms.DockStyle.Left;
            this.numTuoiMin.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.numTuoiMin.Location = new System.Drawing.Point(230, 10);
            this.numTuoiMin.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.numTuoiMin.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.numTuoiMin.Minimum = new decimal(new int[] {
            16,
            0,
            0,
            0});
            this.numTuoiMin.Name = "numTuoiMin";
            this.numTuoiMin.Size = new System.Drawing.Size(52, 15);
            this.numTuoiMin.TabIndex = 75;
            this.numTuoiMin.UpDownButtonFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(177)))), ((int)(((byte)(178)))), ((int)(((byte)(255)))));
            this.numTuoiMin.Value = new decimal(new int[] {
            18,
            0,
            0,
            0});
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Left;
            this.label4.Font = new System.Drawing.Font("Segoe UI Variable Text", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.label4.Location = new System.Drawing.Point(0, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(230, 26);
            this.label4.TabIndex = 1;
            this.label4.Text = "Tuổi tối thiểu của độc giả:";
            // 
            // siticonePanel5
            // 
            this.siticonePanel5.Controls.Add(this.label9);
            this.siticonePanel5.Controls.Add(this.numThoiHan);
            this.siticonePanel5.Controls.Add(this.label5);
            this.siticonePanel5.CustomBorderColor = System.Drawing.Color.MediumSlateBlue;
            this.siticonePanel5.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 1);
            this.siticonePanel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.siticonePanel5.Location = new System.Drawing.Point(15, 71);
            this.siticonePanel5.Margin = new System.Windows.Forms.Padding(3, 1, 3, 3);
            this.siticonePanel5.Name = "siticonePanel5";
            this.siticonePanel5.Padding = new System.Windows.Forms.Padding(0, 10, 0, 4);
            this.siticonePanel5.Size = new System.Drawing.Size(694, 29);
            this.siticonePanel5.TabIndex = 4;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Dock = System.Windows.Forms.DockStyle.Left;
            this.label9.Font = new System.Drawing.Font("Segoe UI Variable Text", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.label9.Location = new System.Drawing.Point(241, 10);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(73, 26);
            this.label9.TabIndex = 77;
            this.label9.Text = "(tháng)";
            // 
            // numThoiHan
            // 
            this.numThoiHan.BackColor = System.Drawing.Color.Transparent;
            this.numThoiHan.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.numThoiHan.Dock = System.Windows.Forms.DockStyle.Left;
            this.numThoiHan.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.numThoiHan.Location = new System.Drawing.Point(189, 10);
            this.numThoiHan.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.numThoiHan.Maximum = new decimal(new int[] {
            18,
            0,
            0,
            0});
            this.numThoiHan.Name = "numThoiHan";
            this.numThoiHan.Size = new System.Drawing.Size(52, 15);
            this.numThoiHan.TabIndex = 76;
            this.numThoiHan.UpDownButtonFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(177)))), ((int)(((byte)(178)))), ((int)(((byte)(255)))));
            this.numThoiHan.Value = new decimal(new int[] {
            6,
            0,
            0,
            0});
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Left;
            this.label5.Font = new System.Drawing.Font("Segoe UI Variable Text", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.label5.Location = new System.Drawing.Point(0, 10);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(189, 26);
            this.label5.TabIndex = 1;
            this.label5.Text = "Thời hạn thẻ độc giả:";
            // 
            // siticonePanel1
            // 
            this.siticonePanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.siticonePanel1.Location = new System.Drawing.Point(15, 62);
            this.siticonePanel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.siticonePanel1.Name = "siticonePanel1";
            this.siticonePanel1.Size = new System.Drawing.Size(694, 9);
            this.siticonePanel1.TabIndex = 9;
            // 
            // siticoneSeparator1
            // 
            this.siticoneSeparator1.Dock = System.Windows.Forms.DockStyle.Top;
            this.siticoneSeparator1.FillColor = System.Drawing.Color.DarkSlateBlue;
            this.siticoneSeparator1.Location = new System.Drawing.Point(15, 52);
            this.siticoneSeparator1.Name = "siticoneSeparator1";
            this.siticoneSeparator1.Size = new System.Drawing.Size(694, 10);
            this.siticoneSeparator1.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Segoe UI Variable Display", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.SlateBlue;
            this.label1.Location = new System.Drawing.Point(15, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(262, 36);
            this.label1.TabIndex = 1;
            this.label1.Text = "Quy định về độc giả";
            // 
            // siticonePanel11
            // 
            this.siticonePanel11.Controls.Add(this.butSave);
            this.siticonePanel11.CustomBorderColor = System.Drawing.Color.MediumSlateBlue;
            this.siticonePanel11.Dock = System.Windows.Forms.DockStyle.Top;
            this.siticonePanel11.Location = new System.Drawing.Point(15, 208);
            this.siticonePanel11.Margin = new System.Windows.Forms.Padding(3, 1, 3, 3);
            this.siticonePanel11.Name = "siticonePanel11";
            this.siticonePanel11.Padding = new System.Windows.Forms.Padding(0, 10, 0, 4);
            this.siticonePanel11.Size = new System.Drawing.Size(694, 41);
            this.siticonePanel11.TabIndex = 76;
            // 
            // butSave
            // 
            this.butSave.BorderRadius = 3;
            this.butSave.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.butSave.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.butSave.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.butSave.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.butSave.Dock = System.Windows.Forms.DockStyle.Right;
            this.butSave.FillColor = System.Drawing.Color.SlateBlue;
            this.butSave.Font = new System.Drawing.Font("Segoe UI Variable Display", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butSave.ForeColor = System.Drawing.Color.White;
            this.butSave.Image = global::GUI.Properties.Resources._69539;
            this.butSave.Location = new System.Drawing.Point(581, 10);
            this.butSave.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.butSave.Name = "butSave";
            this.butSave.Size = new System.Drawing.Size(113, 27);
            this.butSave.TabIndex = 75;
            this.butSave.Text = "Lưu thay đổi";
            this.butSave.Click += new System.EventHandler(this.butSave_Click);
            // 
            // siticonePanel6
            // 
            this.siticonePanel6.Controls.Add(this.checkQDThu);
            this.siticonePanel6.Controls.Add(this.label6);
            this.siticonePanel6.CustomBorderColor = System.Drawing.Color.MediumSlateBlue;
            this.siticonePanel6.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 1);
            this.siticonePanel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.siticonePanel6.Location = new System.Drawing.Point(15, 178);
            this.siticonePanel6.Margin = new System.Windows.Forms.Padding(3, 1, 3, 3);
            this.siticonePanel6.Name = "siticonePanel6";
            this.siticonePanel6.Padding = new System.Windows.Forms.Padding(0, 10, 0, 4);
            this.siticonePanel6.Size = new System.Drawing.Size(694, 30);
            this.siticonePanel6.TabIndex = 15;
            // 
            // checkQDThu
            // 
            this.checkQDThu.CheckedState.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image")));
            this.checkQDThu.Dock = System.Windows.Forms.DockStyle.Left;
            this.checkQDThu.Image = ((System.Drawing.Image)(resources.GetObject("checkQDThu.Image")));
            this.checkQDThu.ImageOffset = new System.Drawing.Point(0, 0);
            this.checkQDThu.ImageRotate = 0F;
            this.checkQDThu.ImageSize = new System.Drawing.Size(25, 25);
            this.checkQDThu.Location = new System.Drawing.Point(375, 10);
            this.checkQDThu.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.checkQDThu.Name = "checkQDThu";
            this.checkQDThu.Size = new System.Drawing.Size(27, 16);
            this.checkQDThu.TabIndex = 2;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Left;
            this.label6.Font = new System.Drawing.Font("Segoe UI Variable Text", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.label6.Location = new System.Drawing.Point(0, 10);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(375, 26);
            this.label6.TabIndex = 1;
            this.label6.Text = "Số tiền thu không được vượt quá số tiền nợ";
            // 
            // siticonePanel2
            // 
            this.siticonePanel2.Controls.Add(this.label14);
            this.siticonePanel2.Controls.Add(this.numKcNam);
            this.siticonePanel2.Controls.Add(this.label15);
            this.siticonePanel2.CustomBorderColor = System.Drawing.Color.MediumSlateBlue;
            this.siticonePanel2.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 1);
            this.siticonePanel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.siticonePanel2.Location = new System.Drawing.Point(15, 149);
            this.siticonePanel2.Name = "siticonePanel2";
            this.siticonePanel2.Padding = new System.Windows.Forms.Padding(0, 10, 0, 4);
            this.siticonePanel2.Size = new System.Drawing.Size(694, 29);
            this.siticonePanel2.TabIndex = 11;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Dock = System.Windows.Forms.DockStyle.Left;
            this.label14.Font = new System.Drawing.Font("Segoe UI Variable Text", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.label14.Location = new System.Drawing.Point(498, 10);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(61, 26);
            this.label14.TabIndex = 78;
            this.label14.Text = "(năm)";
            // 
            // numKcNam
            // 
            this.numKcNam.BackColor = System.Drawing.Color.Transparent;
            this.numKcNam.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.numKcNam.Dock = System.Windows.Forms.DockStyle.Left;
            this.numKcNam.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.numKcNam.Location = new System.Drawing.Point(446, 10);
            this.numKcNam.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.numKcNam.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numKcNam.Name = "numKcNam";
            this.numKcNam.Size = new System.Drawing.Size(52, 15);
            this.numKcNam.TabIndex = 75;
            this.numKcNam.UpDownButtonFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(177)))), ((int)(((byte)(178)))), ((int)(((byte)(255)))));
            this.numKcNam.Value = new decimal(new int[] {
            8,
            0,
            0,
            0});
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Dock = System.Windows.Forms.DockStyle.Left;
            this.label15.Font = new System.Drawing.Font("Segoe UI Variable Text", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.label15.Location = new System.Drawing.Point(0, 10);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(446, 26);
            this.label15.TabIndex = 0;
            this.label15.Text = "Khoảng cách năm xuất bản tối đa có thể nhận sách:";
            // 
            // siticonePanel9
            // 
            this.siticonePanel9.Controls.Add(this.label17);
            this.siticonePanel9.Controls.Add(this.numSoSach);
            this.siticonePanel9.Controls.Add(this.label22);
            this.siticonePanel9.CustomBorderColor = System.Drawing.Color.MediumSlateBlue;
            this.siticonePanel9.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 1);
            this.siticonePanel9.Dock = System.Windows.Forms.DockStyle.Top;
            this.siticonePanel9.Location = new System.Drawing.Point(15, 120);
            this.siticonePanel9.Name = "siticonePanel9";
            this.siticonePanel9.Padding = new System.Windows.Forms.Padding(0, 10, 0, 4);
            this.siticonePanel9.Size = new System.Drawing.Size(694, 29);
            this.siticonePanel9.TabIndex = 12;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Dock = System.Windows.Forms.DockStyle.Left;
            this.label17.Font = new System.Drawing.Font("Segoe UI Variable Text", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.label17.Location = new System.Drawing.Point(239, 10);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(76, 26);
            this.label17.TabIndex = 78;
            this.label17.Text = "(quyển)";
            // 
            // numSoSach
            // 
            this.numSoSach.BackColor = System.Drawing.Color.Transparent;
            this.numSoSach.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.numSoSach.Dock = System.Windows.Forms.DockStyle.Left;
            this.numSoSach.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.numSoSach.Location = new System.Drawing.Point(187, 10);
            this.numSoSach.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.numSoSach.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numSoSach.Name = "numSoSach";
            this.numSoSach.Size = new System.Drawing.Size(52, 15);
            this.numSoSach.TabIndex = 76;
            this.numSoSach.UpDownButtonFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(177)))), ((int)(((byte)(178)))), ((int)(((byte)(255)))));
            this.numSoSach.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Dock = System.Windows.Forms.DockStyle.Left;
            this.label22.Font = new System.Drawing.Font("Segoe UI Variable Text", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.label22.Location = new System.Drawing.Point(0, 10);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(187, 26);
            this.label22.TabIndex = 0;
            this.label22.Text = "Số sách mượn tối đa:";
            // 
            // siticonePanel7
            // 
            this.siticonePanel7.Controls.Add(this.label18);
            this.siticonePanel7.Controls.Add(this.txtDonGia);
            this.siticonePanel7.Controls.Add(this.label19);
            this.siticonePanel7.CustomBorderColor = System.Drawing.Color.MediumSlateBlue;
            this.siticonePanel7.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 1);
            this.siticonePanel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.siticonePanel7.Location = new System.Drawing.Point(15, 91);
            this.siticonePanel7.Name = "siticonePanel7";
            this.siticonePanel7.Padding = new System.Windows.Forms.Padding(0, 10, 0, 4);
            this.siticonePanel7.Size = new System.Drawing.Size(694, 29);
            this.siticonePanel7.TabIndex = 14;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Dock = System.Windows.Forms.DockStyle.Left;
            this.label18.Font = new System.Drawing.Font("Segoe UI Variable Text", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.label18.Location = new System.Drawing.Point(293, 10);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(126, 26);
            this.label18.TabIndex = 86;
            this.label18.Text = "(VNĐ/1 Ngày)";
            // 
            // txtDonGia
            // 
            this.txtDonGia.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtDonGia.DefaultText = "";
            this.txtDonGia.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtDonGia.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtDonGia.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtDonGia.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtDonGia.Dock = System.Windows.Forms.DockStyle.Left;
            this.txtDonGia.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(62)))), ((int)(((byte)(70)))));
            this.txtDonGia.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtDonGia.ForeColor = System.Drawing.Color.Black;
            this.txtDonGia.HoverState.BorderColor = System.Drawing.Color.Silver;
            this.txtDonGia.Location = new System.Drawing.Point(181, 10);
            this.txtDonGia.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtDonGia.Name = "txtDonGia";
            this.txtDonGia.PasswordChar = '\0';
            this.txtDonGia.PlaceholderText = "";
            this.txtDonGia.SelectedText = "";
            this.txtDonGia.Size = new System.Drawing.Size(112, 15);
            this.txtDonGia.TabIndex = 85;
            this.txtDonGia.TextChanged += new System.EventHandler(this.txtDonGia_TextChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Dock = System.Windows.Forms.DockStyle.Left;
            this.label19.Font = new System.Drawing.Font("Segoe UI Variable Text", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.label19.Location = new System.Drawing.Point(0, 10);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(181, 26);
            this.label19.TabIndex = 77;
            this.label19.Text = "Đơn giá phạt trả trễ:";
            // 
            // siticonePanel8
            // 
            this.siticonePanel8.Controls.Add(this.label20);
            this.siticonePanel8.Controls.Add(this.numNgayMuon);
            this.siticonePanel8.Controls.Add(this.label21);
            this.siticonePanel8.CustomBorderColor = System.Drawing.Color.MediumSlateBlue;
            this.siticonePanel8.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 1);
            this.siticonePanel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.siticonePanel8.Location = new System.Drawing.Point(15, 62);
            this.siticonePanel8.Name = "siticonePanel8";
            this.siticonePanel8.Padding = new System.Windows.Forms.Padding(0, 10, 0, 4);
            this.siticonePanel8.Size = new System.Drawing.Size(694, 29);
            this.siticonePanel8.TabIndex = 13;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Dock = System.Windows.Forms.DockStyle.Left;
            this.label20.Font = new System.Drawing.Font("Segoe UI Variable Text", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.label20.Location = new System.Drawing.Point(242, 10);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(65, 26);
            this.label20.TabIndex = 79;
            this.label20.Text = "(ngày)";
            // 
            // numNgayMuon
            // 
            this.numNgayMuon.BackColor = System.Drawing.Color.Transparent;
            this.numNgayMuon.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.numNgayMuon.Dock = System.Windows.Forms.DockStyle.Left;
            this.numNgayMuon.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.numNgayMuon.Location = new System.Drawing.Point(190, 10);
            this.numNgayMuon.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.numNgayMuon.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numNgayMuon.Name = "numNgayMuon";
            this.numNgayMuon.Size = new System.Drawing.Size(52, 15);
            this.numNgayMuon.TabIndex = 78;
            this.numNgayMuon.UpDownButtonFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(177)))), ((int)(((byte)(178)))), ((int)(((byte)(255)))));
            this.numNgayMuon.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Dock = System.Windows.Forms.DockStyle.Left;
            this.label21.Font = new System.Drawing.Font("Segoe UI Variable Text", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.label21.Location = new System.Drawing.Point(0, 10);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(190, 26);
            this.label21.TabIndex = 77;
            this.label21.Text = "Số ngày mượn tối đa:";
            // 
            // siticoneSeparator2
            // 
            this.siticoneSeparator2.Dock = System.Windows.Forms.DockStyle.Top;
            this.siticoneSeparator2.FillColor = System.Drawing.Color.DarkSlateBlue;
            this.siticoneSeparator2.Location = new System.Drawing.Point(15, 52);
            this.siticoneSeparator2.Name = "siticoneSeparator2";
            this.siticoneSeparator2.Size = new System.Drawing.Size(694, 10);
            this.siticoneSeparator2.TabIndex = 16;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Dock = System.Windows.Forms.DockStyle.Top;
            this.label16.Font = new System.Drawing.Font("Segoe UI Variable Display", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.SlateBlue;
            this.label16.Location = new System.Drawing.Point(15, 16);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(386, 36);
            this.label16.TabIndex = 10;
            this.label16.Text = "Quy định về sách và mượn trả";
            // 
            // ucThayDoiQuiDinh
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.infoPanel);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "ucThayDoiQuiDinh";
            this.Size = new System.Drawing.Size(742, 646);
            this.infoPanel.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.siticonePanel3.ResumeLayout(false);
            this.siticonePanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numTuoiMax)).EndInit();
            this.siticonePanel4.ResumeLayout(false);
            this.siticonePanel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numTuoiMin)).EndInit();
            this.siticonePanel5.ResumeLayout(false);
            this.siticonePanel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numThoiHan)).EndInit();
            this.siticonePanel11.ResumeLayout(false);
            this.siticonePanel6.ResumeLayout(false);
            this.siticonePanel6.PerformLayout();
            this.siticonePanel2.ResumeLayout(false);
            this.siticonePanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numKcNam)).EndInit();
            this.siticonePanel9.ResumeLayout(false);
            this.siticonePanel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSoSach)).EndInit();
            this.siticonePanel7.ResumeLayout(false);
            this.siticonePanel7.PerformLayout();
            this.siticonePanel8.ResumeLayout(false);
            this.siticonePanel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numNgayMuon)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Siticone.Desktop.UI.WinForms.SiticonePanel infoPanel;
        private Siticone.Desktop.UI.WinForms.SiticonePanel siticonePanel1;
        private Siticone.Desktop.UI.WinForms.SiticonePanel siticonePanel5;
        private System.Windows.Forms.Label label9;
        private Siticone.Desktop.UI.WinForms.SiticoneNumericUpDown numThoiHan;
        private System.Windows.Forms.Label label5;
        private Siticone.Desktop.UI.WinForms.SiticonePanel siticonePanel4;
        private Siticone.Desktop.UI.WinForms.SiticoneNumericUpDown numTuoiMin;
        private System.Windows.Forms.Label label4;
        private Siticone.Desktop.UI.WinForms.SiticonePanel siticonePanel3;
        private Siticone.Desktop.UI.WinForms.SiticoneNumericUpDown numTuoiMax;
        private System.Windows.Forms.Label label3;
        private Siticone.Desktop.UI.WinForms.SiticoneSeparator siticoneSeparator1;
        private System.Windows.Forms.Label label1;
        private Siticone.Desktop.UI.WinForms.SiticonePanel siticonePanel2;
        private System.Windows.Forms.Label label14;
        private Siticone.Desktop.UI.WinForms.SiticoneNumericUpDown numKcNam;
        private System.Windows.Forms.Label label15;
        private Siticone.Desktop.UI.WinForms.SiticonePanel siticonePanel7;
        private System.Windows.Forms.Label label18;
        private Siticone.Desktop.UI.WinForms.SiticoneTextBox txtDonGia;
        private System.Windows.Forms.Label label19;
        private Siticone.Desktop.UI.WinForms.SiticonePanel siticonePanel8;
        private System.Windows.Forms.Label label20;
        private Siticone.Desktop.UI.WinForms.SiticoneNumericUpDown numNgayMuon;
        private System.Windows.Forms.Label label21;
        private Siticone.Desktop.UI.WinForms.SiticonePanel siticonePanel9;
        private System.Windows.Forms.Label label17;
        private Siticone.Desktop.UI.WinForms.SiticoneNumericUpDown numSoSach;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private Siticone.Desktop.UI.WinForms.SiticonePanel siticonePanel6;
        private Siticone.Desktop.UI.WinForms.SiticoneImageCheckBox checkQDThu;
        private System.Windows.Forms.Label label6;
        private Siticone.Desktop.UI.WinForms.SiticoneSeparator siticoneSeparator2;
        private Siticone.Desktop.UI.WinForms.SiticoneButton butSave;
        private Siticone.Desktop.UI.WinForms.SiticonePanel siticonePanel10;
        private Siticone.Desktop.UI.WinForms.SiticonePanel siticonePanel11;
    }
}
